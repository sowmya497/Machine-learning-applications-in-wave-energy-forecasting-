import shutil
from django.shortcuts import render
from sklearn.model_selection import train_test_split



from .models import userRegisteredTable
from django.core.exceptions import ValidationError
from django.contrib import messages


def userRegisterCheck(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        username = request.POST.get("loginId")
        mobile = request.POST.get("mobile")
        password = request.POST.get("password")
        

        # Create an instance of the model
        user = userRegisteredTable(
            name=name,
            email=email,
            loginid=username,
            mobile=mobile,
            password=password,
            
        )

        try:
            # Validate using model field validators
            user.full_clean()
            
            # Save to DB
            user.save()
            messages.success(request,'registration Successfully done,please wait for admin APPROVAL')
            return render(request, "userRegisterForm.html")


        except ValidationError as ve:
            # Get a list of error messages to display
            error_messages = []
            for field, errors in ve.message_dict.items():
                for error in errors:
                    error_messages.append(f"{field.capitalize()}: {error}")
            return render(request, "userRegisterForm.html", {"messages": error_messages})

        except Exception as e:
            # Handle other exceptions (like unique constraint fails)
            return render(request, "userRegisterForm.html", {"messages": [str(e)]})

    return render(request, "userRegisterForm.html")


def userLoginCheck(request):
    if request.method=='POST':
        username=request.POST['userUsername']
        password=request.POST['userPassword']

        try:
            user=userRegisteredTable.objects.get(loginid=username,password=password)

            if user.status=='Active':
                request.session['id']=user.id
                request.session['name']=user.name
                request.session['email']=user.email
                
                return render(request,'users/userHome.html')
            else:
                messages.error(request,'Status not activated please wait for admin approval')
                return render(request,'userLoginForm.html')
        except:
            messages.error(request,'Invalid details please enter details carefully or Please Register')
            return render(request,'userLoginForm.html')
    return render(request,'userLoginForm.html')


def userHome(request):
    if not request.session.get('id'):
        return render(request,'userLoginForm.html')
    return render(request,'users/userHome.html')

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Suppress TensorFlow warnings

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend - FIXES TKINTER ERRORS
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Conv1D, MaxPooling1D, Flatten
from tensorflow.keras.callbacks import EarlyStopping
import warnings
import joblib
import shutil

def execute_wave_energy_forecasting():
    
    warnings.filterwarnings('ignore')

    # Create media directory if it doesn't exist
    media_dir = 'media'
    os.makedirs(media_dir, exist_ok=True)

    # Load dataset
    df = pd.read_csv(os.path.join(media_dir, 'wave_energy_forecasting_dataset.csv'))
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])

    features = ['Significant_Wave_Height_m', 'Wave_Period_s', 'Wind_Speed_m_s',
                'Wind_Direction_deg', 'Atmospheric_Pressure_hPa', 'Tidal_Height_m']
    target = 'Wave_Power_Density_W_m2'

    # EDA
    print("\n=== Exploratory Data Analysis ===")
    print(df[features + [target]].describe().round(2))

    # Correlation heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(df[features + [target]].corr(), annot=True, cmap='coolwarm', fmt='.2f')
    plt.title('Correlation Heatmap')
    plt.savefig(os.path.join(media_dir, 'correlation_heatmap.png'))
    plt.close()

    # Time-Series Plot
    plt.figure(figsize=(12, 8))
    for feature in features + [target]:
        plt.plot(df['Timestamp'][:168], df[feature][:168], label=feature)
    plt.title('Time-Series Plot (First Week)')
    plt.xlabel('Timestamp')
    plt.ylabel('Value')
    plt.legend()
    plt.savefig(os.path.join(media_dir, 'time_series_plot.png'))
    plt.close()

    # Distribution plots
    plt.figure(figsize=(15, 10))
    for i, feature in enumerate(features + [target], 1):
        plt.subplot(4, 2, i)
        sns.histplot(df[feature], kde=True)
        plt.title(f'Distribution of {feature}')
    plt.tight_layout()
    plt.savefig(os.path.join(media_dir, 'distribution_plots.png'))
    plt.close()

    # Boxplots
    plt.figure(figsize=(12, 8))
    df[features + [target]].boxplot()
    plt.title('Boxplots of Features and Target')
    plt.xticks(rotation=45)
    plt.savefig(os.path.join(media_dir, 'boxplots.png'))
    plt.close()

    # Scatter plots
    plt.figure(figsize=(15, 10))
    for i, feature in enumerate(features, 1):
        plt.subplot(3, 2, i)
        plt.scatter(df[feature], df[target], alpha=0.3)
        plt.title(f'{feature} vs. Wave Power Density')
    plt.tight_layout()
    plt.savefig(os.path.join(media_dir, 'scatter_plots.png'))
    plt.close()

    # Preprocessing
    scaler_features = MinMaxScaler()
    scaler_target = MinMaxScaler()
    df[features] = scaler_features.fit_transform(df[features])
    df[target] = scaler_target.fit_transform(df[[target]])

    def create_sequences(data, seq_length):
        X, y = [], []
        for i in range(len(data) - seq_length):
            X.append(data[i:i + seq_length])
            y.append(data[i + seq_length, -1])
        return np.array(X), np.array(y)

    seq_length = 24
    data = df[features + [target]].values
    X_seq, y_seq = create_sequences(data, seq_length)

    train_size_seq = int(0.7 * len(X_seq))
    val_size_seq = int(0.15 * len(X_seq))
    X_train_seq, y_train_seq = X_seq[:train_size_seq], y_seq[:train_size_seq]
    X_val_seq, y_val_seq = X_seq[train_size_seq:train_size_seq + val_size_seq], y_seq[train_size_seq:train_size_seq + val_size_seq]
    X_test_seq, y_test_seq = X_seq[train_size_seq + val_size_seq:], y_seq[train_size_seq + val_size_seq:]

    X = df[features].values
    y = df[target].values
    train_size = int(0.7 * len(X))
    val_size = int(0.15 * len(X))
    X_train, y_train = X[:train_size], y[:train_size]
    X_val, y_val = X[train_size:train_size + val_size], y[train_size:train_size + val_size]
    X_test, y_test = X[train_size + val_size:], y[train_size + val_size:]

    def calculate_metrics(y_true, y_pred, scaler):
        y_true_inv = scaler.inverse_transform(y_true.reshape(-1, 1))
        y_pred_inv = scaler.inverse_transform(y_pred.reshape(-1, 1))
        rmse = np.sqrt(mean_squared_error(y_true_inv, y_pred_inv))
        mae = mean_absolute_error(y_true_inv, y_pred_inv)
        r2 = r2_score(y_true_inv, y_pred_inv)
        mape = np.mean(np.abs((y_true_inv - y_pred_inv) / np.where(y_true_inv != 0, y_true_inv, 1))) * 100
        return rmse, mae, r2, mape

    results = {}
    models = {}
    histories = {}
    predictions = {}

    # --- LSTM ---
    lstm_model = Sequential([
        LSTM(50, activation='relu', input_shape=(seq_length, len(features) + 1), return_sequences=True),
        Dropout(0.2),
        LSTM(50, activation='relu'),
        Dropout(0.2),
        Dense(1)
    ])
    lstm_model.compile(optimizer='adam', loss='mse')
    early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
    history_lstm = lstm_model.fit(X_train_seq, y_train_seq, epochs=50, batch_size=32,
                                  validation_data=(X_val_seq, y_val_seq), callbacks=[early_stopping], verbose=0)
    y_pred_lstm = lstm_model.predict(X_test_seq, verbose=0)
    results['LSTM'] = dict(zip(['RMSE', 'MAE', 'R2', 'MAPE'], calculate_metrics(y_test_seq, y_pred_lstm, scaler_target)))
    models['LSTM'] = lstm_model
    predictions['LSTM'] = y_pred_lstm

    plt.figure(figsize=(10, 6))
    plt.plot(history_lstm.history['loss'], label='Training Loss')
    plt.plot(history_lstm.history['val_loss'], label='Validation Loss')
    plt.title('LSTM Training Loss')
    plt.legend()
    plt.savefig(os.path.join(media_dir, 'lstm_training_loss.png'))
    plt.close()

    # --- CNN ---
    cnn_model = Sequential([
        Conv1D(64, kernel_size=3, activation='relu', input_shape=(seq_length, len(features) + 1)),
        MaxPooling1D(pool_size=2),
        Conv1D(32, kernel_size=3, activation='relu'),
        MaxPooling1D(pool_size=2),
        Flatten(),
        Dense(50, activation='relu'),
        Dropout(0.2),
        Dense(1)
    ])
    cnn_model.compile(optimizer='adam', loss='mse')
    history_cnn = cnn_model.fit(X_train_seq, y_train_seq, epochs=50, batch_size=32,
                                validation_data=(X_val_seq, y_val_seq), callbacks=[early_stopping], verbose=0)
    y_pred_cnn = cnn_model.predict(X_test_seq, verbose=0)
    results['CNN'] = dict(zip(['RMSE', 'MAE', 'R2', 'MAPE'], calculate_metrics(y_test_seq, y_pred_cnn, scaler_target)))
    models['CNN'] = cnn_model
    predictions['CNN'] = y_pred_cnn

    plt.figure(figsize=(10, 6))
    plt.plot(history_cnn.history['loss'], label='Training Loss')
    plt.plot(history_cnn.history['val_loss'], label='Validation Loss')
    plt.title('CNN Training Loss')
    plt.legend()
    plt.savefig(os.path.join(media_dir, 'cnn_training_loss.png'))
    plt.close()

    # --- XGBoost ---
    xgb_model = XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=5)
    xgb_model.fit(X_train, y_train)
    y_pred_xgb = xgb_model.predict(X_test)
    results['XGBoost'] = dict(zip(['RMSE', 'MAE', 'R2', 'MAPE'], calculate_metrics(y_test, y_pred_xgb, scaler_target)))
    models['XGBoost'] = xgb_model
    predictions['XGBoost'] = y_pred_xgb

    # --- Random Forest ---
    rf_model = RandomForestRegressor(n_estimators=100, max_depth=5, random_state=42)
    rf_model.fit(X_train, y_train)
    y_pred_rf = rf_model.predict(X_test)
    results['Random Forest'] = dict(zip(['RMSE', 'MAE', 'R2', 'MAPE'], calculate_metrics(y_test, y_pred_rf, scaler_target)))
    models['Random Forest'] = rf_model
    predictions['Random Forest'] = y_pred_rf

    # --- SVR ---
    svr_model = SVR(kernel='rbf', C=1.0, epsilon=0.1)
    svr_model.fit(X_train, y_train)
    y_pred_svr = svr_model.predict(X_test)
    results['SVR'] = dict(zip(['RMSE', 'MAE', 'R2', 'MAPE'], calculate_metrics(y_test, y_pred_svr, scaler_target)))
    models['SVR'] = svr_model
    predictions['SVR'] = y_pred_svr

    # --- Linear Regression ---
    lr_model = LinearRegression()
    lr_model.fit(X_train, y_train)
    y_pred_lr = lr_model.predict(X_test)
    results['Linear Regression'] = dict(zip(['RMSE', 'MAE', 'R2', 'MAPE'], calculate_metrics(y_test, y_pred_lr, scaler_target)))
    models['Linear Regression'] = lr_model
    predictions['Linear Regression'] = y_pred_lr

    # --- Save Best Model ---
    best_model = min(results, key=lambda x: results[x]['MAPE'])
    print(f"\nBest Model: {best_model} with MAPE: {results[best_model]['MAPE']:.2f}%")

    if best_model in ['LSTM', 'CNN']:
        models[best_model].save(os.path.join(media_dir, f'best_model_{best_model}.h5'))
    else:
        joblib.dump(models[best_model], os.path.join(media_dir, f'best_model_{best_model}.pkl'))

    # Plot predictions vs actual
    y_pred_best = predictions[best_model]
    y_true_inv = scaler_target.inverse_transform(
        y_test_seq if best_model in ['LSTM', 'CNN'] else y_test.reshape(-1, 1))
    y_pred_inv = scaler_target.inverse_transform(y_pred_best.reshape(-1, 1))

    plt.figure(figsize=(10, 6))
    plt.plot(y_true_inv[:100], label='Actual')
    plt.plot(y_pred_inv[:100], label='Predicted')
    plt.title(f'Actual vs Predicted - {best_model}')
    plt.legend()
    plt.savefig(os.path.join(media_dir, 'best_model_predictions.png'))
    plt.close()

    # Plot MAPE comparison
    plt.figure(figsize=(10, 6))
    sns.barplot(x=[results[model]['MAPE'] for model in results.keys()],
                y=list(results.keys()))
    plt.xlabel('MAPE (%)')
    plt.title('MAPE Comparison Across Models')
    plt.savefig(os.path.join(media_dir, 'mape_comparison.png'))
    plt.close()

    return results, best_model


def training(request):
    if not request.session.get('id'):
        return render(request, 'userLoginForm.html')
    
    results, m = execute_wave_energy_forecasting()
    src_dir = 'media'
    dest_dir = os.path.join('forecast', 'static', 'forecast', 'media')
    os.makedirs(dest_dir, exist_ok=True)
    for file in os.listdir(src_dir):
        if file.endswith('.png'):
            shutil.copy(os.path.join(src_dir, file), os.path.join(dest_dir, file))

    # Prepare data for rendering
    metrics = []
    for model, values in results.items():
        metrics.append({
            'model': model,
            'rmse': f"{values['RMSE']:.2f}",
            'mae': f"{values['MAE']:.2f}",
            'r2': f"{values['R2']:.4f}",
            'mape': f"{values['MAPE']:.2f}"
        })

    image_files = [f for f in os.listdir(dest_dir) if f.endswith('.png')]

    return render(request, 'users/training.html', {
        'metrics': metrics,
        'images': image_files,
        "m": m
    })


def predict_wave_energy(features):
    model_path = os.path.join('media', 'best_model_XGBoost.pkl')  # Update with your model name

    if os.path.exists(model_path):
        model = joblib.load(model_path)
        prediction = model.predict([features])
        return prediction[0]
    else:
        return "Model not found. Please train the model first."


def prediction(request):
    if not request.session.get('id'):
        return render(request, 'userLoginForm.html')

    result = None

    if request.method == 'POST':
        try:
            features = [
                float(request.POST.get('Significant_Wave_Height_m')),
                float(request.POST.get('Wave_Period_s')),
                float(request.POST.get('Wind_Speed_m_s')),
                float(request.POST.get('Wind_Direction_deg')),
                float(request.POST.get('Atmospheric_Pressure_hPa')),
                float(request.POST.get('Tidal_Height_m'))
            ]
            print(features)
            result = predict_wave_energy(features) * 10000
            print(result)

        except (ValueError, TypeError):
            result = "Invalid input. Please enter valid numeric values for all fields."

    return render(request, 'users/prediction.html', {'result': result})