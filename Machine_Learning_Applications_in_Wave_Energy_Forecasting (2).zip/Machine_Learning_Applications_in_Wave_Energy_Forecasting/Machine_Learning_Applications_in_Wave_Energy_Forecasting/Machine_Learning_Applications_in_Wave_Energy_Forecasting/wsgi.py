"""
WSGI config for Classifying_Speech_Disorders_Using_Voice_Signals_Using_Machine_Learing project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/4.1/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Classifying_Speech_Disorders_Using_Voice_Signals_Using_Machine_Learing.settings')

application = get_wsgi_application()
